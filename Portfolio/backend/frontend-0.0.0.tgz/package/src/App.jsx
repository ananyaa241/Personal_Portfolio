import React from 'react';
import CustomCursor from './components/CustomCursor';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import SelectedWork from './components/SelectedWork';
import About from './components/About';
import Experience from './components/Experience';
import SkillsTicker from './components/SkillsTicker';
import Contact from './components/Contact';

function App() {
  return (
    <div className="min-h-screen relative selection:bg-indigo-200 selection:text-indigo-900">
      <CustomCursor />
      <Navigation />

      <main>
        <Hero />
        <SelectedWork />
        <About />
        <Experience />
        <SkillsTicker />
        <Contact />
      </main>
    </div>
  );
}

export default App;
