import React from 'react';
import { motion } from 'framer-motion';
import { portfolioData } from '../api/data';

export default function Contact() {
    const { headline, email, linkedin, github } = portfolioData.contact;

    return (
        <section id="contact" className="py-32 bg-gray-50 relative overflow-hidden">
            {/* Background decorations */}
            <div className="absolute inset-0 bg-[url('https://transparenttextures.com/patterns/cubes.png')] opacity-[0.03]"></div>
            <div className="absolute -bottom-[50%] -left-[10%] w-[80%] h-[150%] bg-gradient-to-tr from-indigo-100 via-pink-50 to-transparent rounded-[100%] opacity-50 z-0"></div>

            <div className="max-w-4xl mx-auto px-6 relative z-10 text-center">
                <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5 }}
                >
                    <div className="inline-block mb-6 px-4 py-1.5 rounded-full bg-white border border-gray-200 text-sm font-semibold text-gray-600 shadow-sm">
                        Status: Accepting New Opportunities
                    </div>

                    <h2 className="text-5xl md:text-7xl font-jakarta font-extrabold text-gray-900 mb-12 tracking-tight">
                        {headline}
                    </h2>

                    <a
                        href={`mailto:${email}`}
                        className="inline-block text-2xl md:text-4xl font-jakarta font-bold text-indigo-600 hover:text-pink-500 transition-colors border-b-4 border-indigo-200 hover:border-pink-300 pb-2 mb-16"
                        data-testid="contact-email"
                    >
                        {email}
                    </a>

                    <div className="flex flex-wrap justify-center gap-6">
                        <a href={linkedin} className="px-8 py-4 bg-white hover:bg-gray-50 text-gray-900 font-semibold rounded-2xl shadow-sm hover:shadow-lg border border-gray-100 transition-all">
                            LinkedIn
                        </a>
                        <a href={github} className="px-8 py-4 bg-white hover:bg-gray-50 text-gray-900 font-semibold rounded-2xl shadow-sm hover:shadow-lg border border-gray-100 transition-all">
                            GitHub
                        </a>
                        <a href="/resume.pdf" download className="px-8 py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-2xl shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all">
                            Download Resume
                        </a>
                    </div>
                </motion.div>
            </div>

            <div className="absolute bottom-6 w-full text-center text-sm font-medium text-gray-400 z-10">
                © {new Date().getFullYear()} Sai Ananya Gajjala. Engineered with intention.
            </div>
        </section>
    );
}
