import React from 'react';
import { motion } from 'framer-motion';
import { portfolioData } from '../api/data';

export default function Hero() {
    const { eyebrow, headline, supportingText, availability, workCounter } = portfolioData.hero;

    const containerVars = {
        hidden: { opacity: 0 },
        show: {
            opacity: 1,
            transition: {
                staggerChildren: 0.15,
                delayChildren: 0.2
            }
        }
    };

    const itemVars = {
        hidden: { opacity: 0, y: 30 },
        show: { opacity: 1, y: 0, transition: { type: 'spring', stiffness: 100, damping: 20 } }
    };

    return (
        <section className="relative min-h-[95vh] flex items-center pt-24 pb-16 overflow-hidden">
            {/* Background elements */}
            <div className="absolute inset-0 z-[-1] bg-[url('https://transparenttextures.com/patterns/cubes.png')] opacity-[0.03]"></div>
            <div className="absolute inset-0 z-[-1] bg-gradient-to-br from-indigo-50 via-white to-pink-50/30"></div>

            {/* Orbit/Circle elements in back */}
            <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 150, repeat: Infinity, ease: 'linear' }}
                className="absolute top-1/4 -right-64 w-[800px] h-[800px] rounded-full border border-gray-200/50 hidden lg:block"
            />
            <motion.div
                animate={{ rotate: -360 }}
                transition={{ duration: 200, repeat: Infinity, ease: 'linear' }}
                className="absolute top-1/3 -right-32 w-[600px] h-[600px] rounded-full border border-dashed border-gray-200/60 hidden lg:block"
            />

            <div className="max-w-7xl mx-auto px-6 w-full flex flex-col lg:flex-row items-center justify-between gap-16 relative">
                <motion.div
                    variants={containerVars}
                    initial="hidden"
                    animate="show"
                    className="w-full lg:w-3/5"
                >
                    <motion.div variants={itemVars} className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-100 mb-6">
                        <span className="w-2 h-2 rounded-full bg-indigo-600 animate-pulse"></span>
                        <span className="text-xs font-semibold text-indigo-800 tracking-wide uppercase">{eyebrow}</span>
                    </motion.div>

                    <motion.h1
                        variants={itemVars}
                        className="text-5xl md:text-7xl font-jakarta font-extrabold text-gray-900 leading-[1.05] tracking-tight mb-8"
                    >
                        {headline}
                    </motion.h1>

                    <motion.p
                        variants={itemVars}
                        className="text-lg md:text-xl text-gray-600 max-w-xl mb-12 leading-relaxed"
                    >
                        {supportingText}
                    </motion.p>

                    <motion.div variants={itemVars} className="flex flex-col sm:flex-row items-center gap-5">
                        <a href="#work" className="w-full sm:w-auto px-8 py-4 bg-indigo-600 text-white rounded-full font-medium shadow-xl shadow-indigo-600/20 hover:shadow-indigo-600/40 hover:-translate-y-1 transition-all text-center" data-testid="explore-work-btn">
                            Explore my work
                        </a>
                        <a href="#contact" className="w-full sm:w-auto px-8 py-4 bg-white text-gray-900 border border-gray-200 rounded-full font-medium hover:bg-gray-50 transition-colors text-center" data-testid="lets-talk-btn">
                            Let's talk
                        </a>
                    </motion.div>

                    {/* Sub info */}
                    <motion.div variants={itemVars} className="mt-16 flex items-center justify-between border-t border-gray-200 pt-6">
                        <div className="text-sm font-medium text-gray-500 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-lime-500"></span>
                            {availability}
                        </div>
                        <div className="text-sm font-medium text-gray-400">
                            {workCounter}
                        </div>
                    </motion.div>
                </motion.div>

                {/* Right side - Profile / Visual area */}
                <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.8, delay: 0.5, type: 'spring' }}
                    className="w-full lg:w-2/5 relative"
                >
                    {/* Stickers */}
                    <motion.div
                        animate={{ y: [0, -10, 0] }}
                        transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                        className="absolute -top-6 -left-8 bg-yellow-400 text-yellow-950 text-xs font-bold px-3 py-2 rounded-lg rotate-[-12deg] shadow-lg z-10"
                    >
                        AI Enthusiast
                    </motion.div>
                    <motion.div
                        animate={{ y: [0, 15, 0] }}
                        transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
                        className="absolute bottom-10 -right-6 bg-cyan-400 text-cyan-950 text-xs font-bold px-3 py-2 rounded-lg rotate-[8deg] shadow-lg z-10"
                    >
                        Problem Solver
                    </motion.div>

                    <div className="relative w-full aspect-[4/5] rounded-[2.5rem] bg-indigo-100 overflow-hidden shadow-2xl glass border-8 border-white">
                        {/* If a real photo is given, replace src below. 
                Using a high-quality abstract / gradient engineering placeholder until then. */}
                        <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500 via-purple-400 to-pink-300 opacity-90 mix-blend-overlay z-10"></div>
                        <img
                            src="https://images.unsplash.com/photo-1555949963-aa79dcee981c?auto=format&fit=crop&q=80&w=800"
                            alt="Engineering Visual placeholder"
                            className="w-full h-full object-cover filter grayscale"
                        />

                        {/* Overlay Grid */}
                        <div className="absolute inset-0 bg-[url('https://transparenttextures.com/patterns/cubes.png')] opacity-20 z-10 mix-blend-overlay"></div>
                    </div>
                </motion.div>
            </div>
        </section>
    );
}
