import React from 'react';
import { motion } from 'framer-motion';
import { portfolioData } from '../api/data';

export default function SkillsTicker() {
    const items = [...portfolioData.skills, ...portfolioData.skills, ...portfolioData.skills];

    return (
        <div className="py-12 bg-gray-900 overflow-hidden relative border-y-8 border-indigo-600">
            <div className="flex whitespace-nowrap">
                <motion.div
                    animate={{ x: ["0%", "-33.33%"] }}
                    transition={{
                        repeat: Infinity,
                        ease: "linear",
                        duration: 20
                    }}
                    className="flex space-x-12 px-6"
                >
                    {items.map((skill, idx) => (
                        <div key={idx} className="flex items-center space-x-12">
                            <span className="text-3xl md:text-5xl font-jakarta font-bold text-white/50 hover:text-white transition-colors cursor-default">
                                {skill}
                            </span>
                            <span className="text-3xl text-indigo-500">✦</span>
                        </div>
                    ))}
                </motion.div>
            </div>
        </div>
    );
}
