import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Menu, X } from 'lucide-react';

export default function Navigation() {
    const [scrolled, setScrolled] = useState(false);
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
            setScrolled(window.scrollY > 50);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const navLinks = [
        { name: 'Work', href: '#work' },
        { name: 'About', href: '#about' },
        { name: 'Experience', href: '#experience' },
        { name: 'Contact', href: '#contact' },
    ];

    return (
        <motion.nav
            initial={{ y: -100 }}
            animate={{ y: 0 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'py-4 glass' : 'py-6 bg-transparent'
                }`}
        >
            <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
                <a href="#" className="text-xl font-jakarta font-bold text-indigo-600 tracking-tight z-50" data-testid="nav-logo">
                    Ananya.
                </a>

                {/* Desktop Nav */}
                <div className="hidden md:flex items-center space-x-8">
                    {navLinks.map((link) => (
                        <a
                            key={link.name}
                            href={link.href}
                            className="text-sm font-medium text-gray-600 hover:text-indigo-600 transition-colors"
                            data-testid={`nav-link-${link.name.toLowerCase()}`}
                        >
                            {link.name}
                        </a>
                    ))}
                    <a
                        href="/resume.pdf"
                        download
                        className="px-5 py-2 text-sm font-medium bg-indigo-600 text-white rounded-full shadow-lg shadow-indigo-600/20 hover:shadow-indigo-600/40 hover:-translate-y-0.5 transition-all"
                        data-testid="nav-resume-btn"
                    >
                        Resume
                    </a>
                </div>

                {/* Mobile menu button */}
                <button
                    className="md:hidden z-50 p-2 -mr-2 text-gray-600"
                    onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                    data-testid="mobile-menu-btn"
                >
                    {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
                </button>

                {/* Mobile Nav */}
                <motion.div
                    initial={false}
                    animate={mobileMenuOpen ? 'open' : 'closed'}
                    variants={{
                        open: { x: 0, opacity: 1 },
                        closed: { x: '100%', opacity: 0 }
                    }}
                    transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                    className="fixed inset-0 bg-white/95 backdrop-blur-xl z-40 flex flex-col justify-center items-center space-y-8 md:hidden"
                >
                    {navLinks.map((link) => (
                        <a
                            key={link.name}
                            href={link.href}
                            className="text-2xl font-jakarta font-semibold text-gray-900"
                            onClick={() => setMobileMenuOpen(false)}
                        >
                            {link.name}
                        </a>
                    ))}
                    <a
                        href="/resume.pdf"
                        download
                        className="px-8 py-3 text-lg font-medium bg-indigo-600 text-white rounded-full shadow-xl"
                        onClick={() => setMobileMenuOpen(false)}
                    >
                        Download Resume
                    </a>
                </motion.div>
            </div>
        </motion.nav>
    );
}
