import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ExternalLink, Github, X } from 'lucide-react';
import { portfolioData } from '../api/data';

export default function SelectedWork() {
    const [selectedProject, setSelectedProject] = useState(null);

    const colors = [
        'bg-cyan-100', 'bg-pink-100', 'bg-yellow-100', 'bg-lime-100', 'bg-violet-100'
    ];
    const borderColors = [
        'border-cyan-200', 'border-pink-200', 'border-yellow-200', 'border-lime-200', 'border-violet-200'
    ];

    return (
        <section id="work" className="py-32 relative bg-white">
            <div className="max-w-7xl mx-auto px-6">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="mb-16"
                >
                    <h2 className="text-4xl md:text-5xl font-jakarta font-bold text-gray-900 mb-4">Selected Work.</h2>
                    <p className="text-xl text-gray-500">Case studies of products I've engineered.</p>
                </motion.div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {portfolioData.projects.map((project, idx) => (
                        <motion.div
                            key={project.id}
                            whileHover={{ y: -10, scale: 1.02 }}
                            initial={{ opacity: 0, y: 30 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.4, delay: idx * 0.1 }}
                            onClick={() => setSelectedProject(project)}
                            className={`p-8 rounded-[2rem] cursor-pointer shadow-sm hover:shadow-xl transition-all border ${colors[idx % colors.length]} ${borderColors[idx % borderColors.length]}`}
                            data-testid={`project-card-${project.id}`}
                        >
                            <div className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-4">{project.category}</div>
                            <h3 className="text-2xl font-jakarta font-bold text-gray-900 mb-2">{project.title}</h3>
                            <p className="text-sm font-medium text-gray-700 mb-6 bg-white/50 inline-block px-3 py-1 rounded-full">{project.impact}</p>

                            <div className="flex flex-wrap gap-2 mt-auto pt-6 border-t border-black/5">
                                {project.techStack.slice(0, 3).map(tech => (
                                    <span key={tech} className="text-xs font-semibold bg-white px-2 py-1 rounded-md text-gray-600 shadow-sm">
                                        {tech}
                                    </span>
                                ))}
                                {project.techStack.length > 3 && (
                                    <span className="text-xs font-semibold bg-white px-2 py-1 rounded-md text-gray-600 shadow-sm">
                                        +{project.techStack.length - 3}
                                    </span>
                                )}
                            </div>
                        </motion.div>
                    ))}
                </div>
            </div>

            {/* Modal */}
            <AnimatePresence>
                {selectedProject && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6"
                    >
                        <div className="absolute inset-0 bg-gray-900/40 backdrop-blur-sm" onClick={() => setSelectedProject(null)}></div>

                        <motion.div
                            initial={{ y: 50, opacity: 0, scale: 0.9 }}
                            animate={{ y: 0, opacity: 1, scale: 1 }}
                            exit={{ y: 20, opacity: 0, scale: 0.95 }}
                            className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl overflow-hidden glass-card p-0"
                            data-testid={`modal-${selectedProject.id}`}
                        >
                            <button
                                onClick={() => setSelectedProject(null)}
                                className="absolute top-6 right-6 p-2 bg-gray-100 hover:bg-gray-200 rounded-full text-gray-600 z-10 transition-colors"
                            >
                                <X size={20} />
                            </button>

                            <div className={`p-8 md:p-12 ${colors[portfolioData.projects.findIndex(p => p.id === selectedProject.id) % colors.length]}`}>
                                <div className="text-sm font-bold uppercase tracking-wider text-gray-600 mb-4">{selectedProject.category}</div>
                                <h3 className="text-3xl md:text-5xl font-jakarta font-bold text-gray-900 mb-4">{selectedProject.title}</h3>
                                <div className="inline-block px-4 py-2 bg-white rounded-full text-sm font-semibold text-gray-800 shadow-sm mb-6">
                                    Impact: {selectedProject.impact}
                                </div>
                            </div>

                            <div className="p-8 md:p-12">
                                <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                                    {selectedProject.description}
                                </p>

                                <div className="mb-8">
                                    <h4 className="text-sm font-bold text-gray-900 uppercase tracking-widest mb-4">Technologies</h4>
                                    <div className="flex flex-wrap gap-2">
                                        {selectedProject.techStack.map(tech => (
                                            <span key={tech} className="text-sm font-medium bg-gray-100 border border-gray-200 px-3 py-1.5 rounded-lg text-gray-700">
                                                {tech}
                                            </span>
                                        ))}
                                    </div>
                                </div>

                                <div className="flex space-x-4 pt-6 border-t border-gray-100">
                                    <a href={selectedProject.githubUrl} className="flex items-center space-x-2 px-5 py-2.5 bg-gray-900 hover:bg-gray-800 text-white rounded-xl transition-colors font-medium">
                                        <Github size={18} />
                                        <span>View Source</span>
                                    </a>
                                    <a href={selectedProject.demoUrl} className="flex items-center space-x-2 px-5 py-2.5 bg-white border border-gray-200 hover:bg-gray-50 text-gray-900 rounded-xl transition-colors font-medium">
                                        <ExternalLink size={18} />
                                        <span>Live Demo</span>
                                    </a>
                                </div>
                            </div>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </section>
    );
}
