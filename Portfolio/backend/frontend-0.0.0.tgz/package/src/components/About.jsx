import React from 'react';
import { motion } from 'framer-motion';
import { portfolioData } from '../api/data';

export default function About() {
    const { about } = portfolioData;

    return (
        <section id="about" className="py-24 bg-gray-50 relative border-y border-gray-100">
            <div className="max-w-7xl mx-auto px-6">
                <div className="flex flex-col md:flex-row gap-16 items-center">

                    <motion.div
                        initial={{ opacity: 0, x: -30 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        className="w-full md:w-1/2"
                    >
                        <h2 className="text-3xl md:text-5xl font-jakarta font-bold text-gray-900 mb-6 leading-tight">
                            {about.headline}
                        </h2>
                        <p className="text-lg text-gray-600 leading-relaxed mb-10">
                            {about.description}
                        </p>

                        <div className="grid grid-cols-3 gap-6 pt-8 border-t border-gray-200">
                            <div>
                                <div className="text-3xl font-jakarta font-bold text-indigo-600 mb-1">{about.stats.cgpa}</div>
                                <div className="text-xs uppercase font-bold tracking-wider text-gray-500">CGPA</div>
                            </div>
                            <div>
                                <div className="text-3xl font-jakarta font-bold text-pink-500 mb-1">{about.stats.featuredBuilds}</div>
                                <div className="text-xs uppercase font-bold tracking-wider text-gray-500">Featured Builds</div>
                            </div>
                            <div>
                                <div className="text-3xl font-jakarta font-bold text-cyan-500 mb-1">{about.stats.hackathonRecognitions}</div>
                                <div className="text-xs uppercase font-bold tracking-wider text-gray-500">Hackathon Wins</div>
                            </div>
                        </div>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        viewport={{ once: true }}
                        className="w-full md:w-1/2"
                    >
                        <div className="bg-white p-8 rounded-[2rem] shadow-xl border border-gray-100 relative overflow-hidden">
                            {/* Decorative background element */}
                            <div className="absolute top-0 right-0 w-32 h-32 bg-lime-200 rounded-full blur-3xl opacity-50 transform translate-x-1/2 -translate-y-1/2"></div>

                            <h3 className="text-xl font-jakarta font-bold text-gray-900 mb-6">Education</h3>
                            <div className="space-y-6">
                                {portfolioData.education.map((edu, idx) => (
                                    <div key={idx} className="relative pl-6 before:absolute before:left-0 before:top-2 before:w-2 before:h-2 before:bg-indigo-600 before:rounded-full">
                                        <h4 className="font-bold text-gray-900 text-lg">{edu.institution}</h4>
                                        <p className="text-sm text-gray-600 font-medium my-1">{edu.degree}</p>
                                        <div className="flex justify-between items-center text-xs text-gray-400 mt-2">
                                            <span className="font-semibold text-gray-500">{edu.score}</span>
                                            <span>{edu.location}</span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </motion.div>

                </div>
            </div>
        </section>
    );
}
