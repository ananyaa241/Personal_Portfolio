import React from 'react';
import { motion } from 'framer-motion';
import { portfolioData } from '../api/data';

export default function Experience() {
    return (
        <section id="experience" className="py-24 bg-white">
            <div className="max-w-7xl mx-auto px-6">

                <div className="flex flex-col lg:flex-row gap-16">
                    <div className="w-full lg:w-2/3">
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                        >
                            <h2 className="text-4xl md:text-5xl font-jakarta font-bold text-gray-900 mb-12">Experience.</h2>
                        </motion.div>

                        <div className="space-y-12">
                            {portfolioData.experience.map((exp, idx) => (
                                <motion.div
                                    key={idx}
                                    initial={{ opacity: 0, y: 20 }}
                                    whileInView={{ opacity: 1, y: 0 }}
                                    viewport={{ once: true }}
                                    transition={{ delay: 0.1 }}
                                    className="relative pl-8 md:pl-0"
                                >
                                    {/* Timeline line hidden on mobile, visible on desktop */}
                                    <div className="hidden md:block absolute left-[-40px] top-2 bottom-0 w-px bg-gray-200"></div>
                                    <div className="hidden md:block absolute left-[-44px] top-2 w-2 h-2 rounded-full bg-indigo-600 ring-4 ring-white"></div>

                                    <div className="mb-2 flex flex-col md:flex-row md:items-baseline md:justify-between">
                                        <h3 className="text-2xl font-jakarta font-bold text-gray-900">{exp.role}</h3>
                                        <span className="text-sm font-semibold text-indigo-600 whitespace-nowrap mt-1 md:mt-0">{exp.date}</span>
                                    </div>
                                    <p className="text-lg font-medium text-gray-600 mb-6">{exp.company}</p>

                                    <ul className="space-y-3">
                                        {exp.highlights.map((highlight, i) => (
                                            <li key={i} className="text-gray-600 flex items-start">
                                                <span className="text-indigo-400 mr-3 mt-1.5">•</span>
                                                <span className="leading-relaxed">{highlight}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </motion.div>
                            ))}
                        </div>
                    </div>

                    <div className="w-full lg:w-1/3">
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                        >
                            <h2 className="text-2xl font-jakarta font-bold text-gray-900 mb-8 mt-4 lg:mt-0">Hackathons & Recognition</h2>
                        </motion.div>

                        <div className="space-y-6">
                            {portfolioData.recognition.map((rec, idx) => (
                                <motion.div
                                    key={idx}
                                    initial={{ opacity: 0, x: 20 }}
                                    whileInView={{ opacity: 1, x: 0 }}
                                    viewport={{ once: true }}
                                    transition={{ delay: idx * 0.1 }}
                                    className="bg-gray-50 border border-gray-100 p-6 rounded-2xl hover:border-violet-200 hover:shadow-md transition-all group"
                                >
                                    <h4 className="font-bold text-gray-900 mb-2 group-hover:text-violet-600 transition-colors uppercase text-sm tracking-wide">{rec.title}</h4>
                                    <p className="text-gray-600 text-sm font-medium">{rec.subtitle}</p>
                                </motion.div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}
