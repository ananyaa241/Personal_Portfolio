/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        jakarta: ['"Plus Jakarta Sans"', 'sans-serif'],
        inter: ['Inter', 'sans-serif'],
      },
      colors: {
        accent: {
          cyan: '#06b6d4',
          pink: '#ec4899',
          yellow: '#eab308',
          lime: '#84cc16',
          violet: '#8b5cf6',
          indigo: '#4f46e5',
        }
      },
      animation: {
        'spin-slow': 'spin 8s linear infinite',
        'wiggle': 'wiggle 3s ease-in-out infinite',
      },
      keyframes: {
        wiggle: {
          '0%, 100%': { transform: 'rotate(-3deg)' },
          '50%': { transform: 'rotate(3deg)' },
        }
      }
    },
  },
  plugins: [],
}
